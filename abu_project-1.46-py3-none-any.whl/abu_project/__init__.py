from .funny import FunnyFuncs
__all__ = ["FunnyFuncs"]